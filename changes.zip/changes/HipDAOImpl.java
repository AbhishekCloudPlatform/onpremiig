package com.iig.gcp.hipdashboard.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.stereotype.Component;

import com.iig.gcp.feedlogging.dto.FeedLoggerDTO;
import com.iig.gcp.hipdashboard.dto.HipDashboardDTO;
import com.iig.gcp.utils.ConnectionUtils;
@Component
public class HipDAOImpl implements HipDAO {

	
	@Override
	public ArrayList<String> getfeeds() throws SQLException, Exception {
		ArrayList<String> arr = new ArrayList<String>();
		Connection connection = null;
		ResultSet rs =null;
		PreparedStatement pstm =null;
		try {
			connection = ConnectionUtils.getConnection();
			 pstm = connection.prepareStatement("select distinct feed_id from logger_master order by feed_id");
			 rs = pstm.executeQuery();
			while (rs.next()) {
				arr.add(rs.getString(1));
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}	
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(connection);
		return arr;
	}
	
	@Override
	public ArrayList<FeedLoggerDTO> getfeeddetails(String feed_id) throws SQLException, Exception {
		ArrayList<FeedLoggerDTO> arr = new ArrayList<FeedLoggerDTO>();
		Connection connection = null;
		PreparedStatement pstm =null;
		ResultSet rs= null;
		try {
			connection = ConnectionUtils.getConnection();
			 pstm = connection.prepareStatement("select * from logger_master where feed_id='"+feed_id+"'");
			 rs = pstm.executeQuery();
			while (rs.next()) {
				FeedLoggerDTO fl=new FeedLoggerDTO();
				fl.setFeed_id(rs.getString(1));
				fl.setClassification(rs.getString(2));
				fl.setSubclassification(rs.getString(3));
				fl.setValue(rs.getString(4));
				arr.add(fl);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}	
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(connection);
		return arr;
	}

	@Override
	public ArrayList<String> getfeedsFromLoggerStats() throws SQLException, Exception {
		ArrayList<String> arr = new ArrayList<String>();
		Connection connection = null;
		PreparedStatement pstm =null;
		ResultSet rs= null;
		try {
			connection = ConnectionUtils.getConnection();
			 pstm = connection.prepareStatement("select distinct event_feed_id from logger_stats_master order by event_feed_id");
			 rs = pstm.executeQuery();
			while (rs.next()) {
				arr.add(rs.getString(1));
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}	
		
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(connection);
		return arr;
	}

	@Override
	public ArrayList<HipDashboardDTO> getTableChartLoggerStats(@Valid String feed_id) throws SQLException, Exception {
		// TODO Auto-generated method stub
		ArrayList<HipDashboardDTO> arrHipDashboard=new ArrayList<HipDashboardDTO>();
		HipDashboardDTO hipDashboardDTO = null;
		Connection conn = ConnectionUtils.getConnection();
		PreparedStatement pstm = conn.prepareStatement("select event_feed_id, TO_CHAR(event_batch_date,'YYYY-MM-DD') as event_batch_date,event_run_id,start_time,end_time,CAST(duration as DECIMAL(20,2)) as duration FROM ( SELECT st.event_feed_id, st.event_batch_date, st.event_run_id, st.event_value AS start_time, en.event_value AS end_time, (TO_DATE(concat(concat(en.event_batch_date, ' '), en.event_value), 'DD-MM-YY hh24:mi:ss') - TO_DATE(concat(concat(st. event_batch_date, ' '), st.event_value), 'DD-MM-YY hh24:mi:ss')) * 1440 AS duration FROM ( SELECT * FROM logger_stats_master WHERE event_type = 'start' ) st INNER JOIN ( SELECT * FROM logger_stats_master WHERE event_type = 'end' ) en ON st.event_feed_id = en.event_feed_id AND st.event_run_id = en.event_run_id AND st.event_batch_date = en.event_batch_date ) a WHERE event_feed_id = ? ORDER BY event_batch_date");
		pstm.setString(1, feed_id);
		ResultSet rs = pstm.executeQuery();
		while (rs.next()) {
			hipDashboardDTO = new HipDashboardDTO();
			hipDashboardDTO.setBatch_id(rs.getString(1));
			hipDashboardDTO.setBatch_date(rs.getString(2));
			hipDashboardDTO.setRun_id(rs.getString(3));
			hipDashboardDTO.setStart_time(rs.getString(4));
			hipDashboardDTO.setEnd_time(rs.getString(5));
			hipDashboardDTO.setDuration(rs.getString(6));
			
			arrHipDashboard.add(hipDashboardDTO);
		}
		
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(conn);
		return arrHipDashboard;
	}

	@Override
	public String checkFeedAvailable(@Valid String feed_id) throws SQLException, Exception {
		System.out.println("feed id"+feed_id);
		
		Connection connection=null;
		int stat=1;
		String strfeed_id=null;
			connection = ConnectionUtils.getConnection();
			PreparedStatement pstm = connection.prepareStatement("select event_feed_id from logger_stats_master where event_feed_id='"+feed_id+"'");
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				strfeed_id=rs.getString(1);
				stat=0;
				break;
			}
			ConnectionUtils.closeResultSet(rs);
			ConnectionUtils.closePrepareStatement(pstm);
			ConnectionUtils.closeQuietly(connection);
		return stat+strfeed_id;
	}

	@Override
	public ArrayList<HipDashboardDTO> getTablechartUsingDate(@Valid String feedIdFilter, String dateRangeText)
			throws SQLException, Exception {
	    //Date date2=Date.valueOf(date);//converting string into sql date  
		String start_date="";
		String end_date="";
	    
	    if(dateRangeText.contains("-")) {
			String[] dates = dateRangeText.split("-");
			String first_date = dates[0].trim();
			String last_date = dates[1].trim();
			
			Date sd = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(first_date);
			start_date=new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(sd);
			Date ed = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(last_date);
			end_date=new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(ed);
			
		} else {
			String date = dateRangeText.trim();
			Date sd = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(date);
			start_date=new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(sd);
			end_date = start_date;
		}
		
		ArrayList<HipDashboardDTO> arrHipDashboard=new ArrayList<HipDashboardDTO>();
		HipDashboardDTO hipDashboardDTO = null;
		Connection conn = ConnectionUtils.getConnection();
		PreparedStatement pstm = conn.prepareStatement("select event_feed_id, TO_CHAR(event_batch_date,'YYYY-MM-DD') as event_batch_date,event_run_id,start_time,end_time,CAST(duration as DECIMAL(20,2)) as duration from (select st.event_feed_id, st.event_batch_date, st.event_run_id, st.event_value as start_time, en.event_value as end_time, ( TO_DATE(concat(concat(en.event_batch_date, ' '), en.event_value), 'DD-MM-YY hh24:mi:ss') - TO_DATE(concat(concat(st.event_batch_date, ' '), st.event_value), 'DD-MM-YY hh24:mi:ss') ) * 1440 AS duration from (select * from logger_stats_master where event_type='start' and event_feed_id = ?) st inner join (select * from logger_stats_master where event_type='end' and event_feed_id = ?) en on st.event_feed_id=en.event_feed_id and st.event_run_id=en.event_run_id and st.event_batch_date=en.event_batch_date)a where event_batch_date between TO_DATE(?,'YYYY-MM-DD') and (TO_DATE(?,'YYYY-MM-DD')) order by event_batch_date");
		pstm.setString(1, feedIdFilter);
		pstm.setString(2, feedIdFilter);
		pstm.setString(3, start_date);
		pstm.setString(4, end_date);
		
		ResultSet rs = pstm.executeQuery();
		while (rs.next()) {
			hipDashboardDTO = new HipDashboardDTO();
			hipDashboardDTO.setBatch_id(rs.getString(1));
			hipDashboardDTO.setBatch_date(rs.getString(2));
			hipDashboardDTO.setRun_id(rs.getString(3));
			hipDashboardDTO.setStart_time(rs.getString(4));
			hipDashboardDTO.setEnd_time(rs.getString(5));
			hipDashboardDTO.setDuration(rs.getString(6));
			
			arrHipDashboard.add(hipDashboardDTO);
		}
		for(HipDashboardDTO x:arrHipDashboard) {
			System.out.println(x.getDuration());
		}
		
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(conn);
		return arrHipDashboard;	
		
	}

	@Override
	public ArrayList<String> getFeedTables(@Valid String feed_id) throws SQLException, Exception {
		ArrayList<String> arr = new ArrayList<String>();
		Connection connection = null;
		ResultSet rs =null;
		PreparedStatement pstm =null;
		connection = ConnectionUtils.getConnection();
		pstm = connection.prepareStatement("select distinct feed_id from logger_master order by feed_id");
		rs = pstm.executeQuery();
		while (rs.next()) {
			arr.add(rs.getString(1));
		}	
		ConnectionUtils.closeResultSet(rs);
		ConnectionUtils.closePrepareStatement(pstm);
		ConnectionUtils.closeQuietly(connection);
		return arr;
	}
	
	
	
	
	
	
}
